//
//  PoyntLib.h
//  PoyntLib
//
//  Created by Eric McConkie on 2/22/16.
//  Copyright © 2016 poynt.co. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PoyntLib.
FOUNDATION_EXPORT double PoyntLibVersionNumber;

//! Project version string for PoyntLib.
FOUNDATION_EXPORT const unsigned char PoyntLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PoyntLib/PublicHeader.h>


